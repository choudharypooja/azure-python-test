
import logging

class OktaLogCollector:
    def collect_logs():
        logging.info("call from other function with class")
