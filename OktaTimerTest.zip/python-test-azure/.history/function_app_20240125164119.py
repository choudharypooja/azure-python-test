import azure.functions as func
import datetime
import json
import logging
import requests
import os
import sys
from sys import path
# import constants as const
# import helper as hp
#from .okta_log_collector import OktaLogCollector
# import storage_account as acc
import json
import logging
import requests
from datetime import datetime, timedelta, timezone
import os
import validators
#import storage_account
#import constants as const
#import helper as hp
#from log_ingester import LogIngester
#import msgspec_okta_event

OKTA_LOGS_ENDPOINT = "/api/v1/logs"
HTTP_PROTOCOL = "https://"
OKTA_EVENT_FILTER = "OKTA_EVENT_FILTER"
OKTA_EVENT_KEYWORD = "OKTA_EVENT_KEYWORD"
OKTA_NEXT_LINK = "okta_next_link"
RETRIES = "next_link_retries"
MAX_RETRIES = 3
BACK_FILL_DURATION_MINUTES = 2

# logger = logging.getLogger()
# logger.setLevel(logging.INFO)

# domain = "logicmonitorpreview.oktapreview.com"#hp.get_attr_from_env(const.OKTA_DOMAIN)
# api_key = "00c2SamWJ6AiRS9TByggjjrcPtlDDTO3JCakkvPT_W"#hp.get_required_attr_from_env(const.OKTA_API_KEY)
#         #self.log_ingester = LogIngester()
# back_fill_dur_min = BACK_FILL_DURATION_MINUTES
# retry_attempt = 0
# # dir_path = os.path.dirname(os.path.realpath(__file__))
# # sys.path.insert(0, dir_path)

app = func.FunctionApp()
#oktaLog = OktaLogCollector()
@app.schedule(schedule="*/30 * * * * *", arg_name="myTimerTest", run_on_startup=True,
              use_monitor=False) 
def MyTimerTrigger1(myTimerTest: func.TimerRequest) -> None:
    logging.info('Python timer trigger function executing uploaded using zip.')
    if myTimerTest.past_due:
        logging.info('The timer is past due!')
    
    #collect_logs()
    logging.info('Python timer trigger function executed.')
