
import logging


def collect_logs():
    logging.info("call from other function")
